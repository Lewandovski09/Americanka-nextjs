// Server-side Supabase client for use in Server Components, Server
// Actions, and Route Handlers. Reads/writes the user's session from
// cookies so authentication persists across requests.

import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { cookies } from 'next/headers';

interface CookieToSet {
  name: string;
  value: string;
  options: CookieOptions;
}

export function createClient() {
  const cookieStore = cookies();

  // See client.ts for why the `!` is safe here: a missing env var
  // already made the old .js client throw immediately at runtime.
  return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: {
      getAll() {
        return cookieStore.getAll();
      },
      setAll(cookiesToSet: CookieToSet[]) {
        try {
          cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options));
        } catch {
          // Called from a Server Component where cookies can't be
          // set directly — safe to ignore, middleware refreshes
          // the session instead.
        }
      },
    },
  });
}
